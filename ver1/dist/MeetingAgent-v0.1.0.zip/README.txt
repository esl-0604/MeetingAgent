Meeting Agent — Teams 미팅 캡처 도구
=======================================

요구 환경
---------
- Windows 10 (build 19041 / 2004) 이상, Windows 11 권장
- New Teams (Classic Teams 아님)
- 64-bit (x86_64) PC

설치
----
없음. meeting-agent.exe 한 파일을 원하는 폴더에 두면 끝.
(예: 바탕화면, C:\Tools\, 또는 USB 메모리)

처음 실행 시 SmartScreen 경고
------------------------------
서명되지 않은 .exe는 Windows에서 경고를 띄웁니다.
"추가 정보" → "실행" 클릭하면 됩니다.
이후 실행에서는 경고가 다시 안 뜹니다.

사용법
------
1. New Teams를 켜고 미팅에 참여합니다.
2. 미팅 화면에서 [···] → "언어 및 음성" → "라이브 캡션 켜기"
   (한 번만 켜두면 이후 미팅에서도 유지됨)
3. 폴더의 run.bat를 더블클릭하거나, PowerShell/CMD에서:

       meeting-agent.exe

   미팅이 감지되면 폴더 선택 다이얼로그가 한 번 뜹니다.
   - 저장 위치를 고르고 [선택] 클릭 → 그 폴더에 바로 녹화 시작
   - 취소하면 기본 위치(아래)에 녹화
   - 다음 실행에서는 이 위치가 미리 선택돼 있어서 Enter만 누르면 됨

4. 미팅이 끝나거나 Ctrl-C를 누르면 즉시 종료 (이동/복사 없음).

캡처 결과
---------
다이얼로그를 취소했거나 첫 실행이라면 기본 위치 사용:
   C:\Users\<사용자명>\Documents\MeetingAgent\sessions\YYYY-MM-DD-HHMMSS-MeetingSession\

("내 문서" 폴더가 OneDrive 등으로 redirect 되어 있으면 그쪽을 따라갑니다.)

세션 폴더에는 단 2개 파일만 남습니다:

   meeting.mp4       1080p H.264 + AAC
                     - Teams 음성 + 내 마이크 믹싱
                     - 화면공유 시 자동으로 공유 윈도우 녹화로 전환
                       (다른 사람 공유 시: Teams 창)
                       (내가 공유 시: 공유한 그 윈도우)
   transcript.txt    [HH:MM:SS.mmm] Speaker: text 한 줄/문장
                     (Teams 라이브 캡션을 읽어 저장)

영상 캡처가 정상 종료 못 하면 (드물지만 강제 종료 등) 복구용으로
events.jsonl이 남습니다. 정상 종료 시엔 자동 삭제.

별도 WAV 파일은 더 이상 만들어지지 않습니다 — MP4에 음성이 모두 들어갑니다.
긴 미팅(1시간 이상)에서 종료 후 대기시간이 거의 없는 이유.

"기본 위치"는 한 번 바꾸면 고정됩니다
-------------------------------------
미팅 시작 시 폴더 선택 창에서 폴더를 한 번 고르면, 그 폴더가
다음부터의 새 기본 위치가 됩니다.
- 다음 선택 창은 그 폴더가 미리 선택된 상태로 열립니다 → Enter만 누르면 OK
- 이 "마지막 선택" 기억은 %APPDATA%\MeetingAgent\state.json 에 저장됩니다.
  (config.json과는 별개의 내부 메모리 파일)
- 기억을 리셋하려면 그 state.json 파일을 지우세요.

옵션
----
   --output 경로            세션 저장 위치 변경 (config.json 무시)
   --no-prompt-save         시작 시 폴더 묻는 다이얼로그 비활성화
                            (자동화/배치 실행 시 유용)
   --prompt-save            반대로 강제 활성화 (config 덮어쓰기)
   --force-start            Teams 미팅 감지 없이 바로 시작 (테스트용)
   --log meeting_agent=debug  디버그 로그
   --diagnose               미팅 감지가 안 될 때: Teams UIA 트리 dump
   --diagnose-captions      자막은 보이는데 못 잡을 때: 캡션 컨테이너 dump
   --diagnose-share         공유 중일 때 실행: Teams가 share에 노출하는
                            UIA 노드 + 모니터/윈도우 목록 dump
   --help                   전체 옵션

종료 동작 요약
--------------
   Ctrl-C / 미팅 자동 종료 → finalize → 즉시 종료 (이동/복사 없음)
   콘솔 X 버튼 / 로그오프 / 시스템 종료 → 5초 안에 자동 finalize → 즉시 종료
   taskkill /F     → 강제 즉살 → MP4 미완성 가능 (mdat은 있고 moov 없음)
                     → ffmpeg로 복구 가능

시작 시 다이얼로그 끄고 싶으면:
- 임시: meeting-agent.exe --no-prompt-save
- 영구: %APPDATA%\MeetingAgent\config.json 에서
        "prompt_save_on_exit": false

자기가 발표할 때 (화면 공유) 동작
-----------------------------------
- Teams가 공유 시작을 감지하면 비디오 캡처 소스를 자동 전환:
  * "윈도우 공유" 모드 → 공유한 그 윈도우만 캡처
    (다른 데스크톱 영역은 안 들어감 — privacy)
  * "화면 공유" 모드 → 공유한 모니터 캡처
- Teams가 공유 중인 윈도우의 정확한 식별자를 외부에 노출하지 않으므로,
  공유 시작 직후의 포그라운드 윈도우를 사용합니다.
  (= 공유할 윈도우를 클릭한 직후 "공유" 버튼을 누르는 일반적 워크플로우면 정확)
- 공유 중에 다른 윈도우로 Alt-Tab해도 캡처 대상은 안 바뀝니다.
  바꾸려면 공유를 정지 → 새 윈도우 클릭 → 다시 공유.

알려진 한계
-----------
- Teams 라이브 캡션이 켜진 상태에서만 transcript.txt가 채워집니다.
  (캡션을 만들어내지는 않습니다 — Teams의 캡션을 읽어가는 것)
- Teams 자체 녹화 기능과는 별개로 동작하며, 참석자에게 녹화 알림이
  뜨지 않습니다. 조직 정책에 따라 사전 고지가 필요할 수 있습니다.
- 1080p / 6 Mbps / 10 fps 고정. 더 높은 해상도/비트레이트는 미지원.
